import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacts-view',
  templateUrl: './contacts-view.component.html',
  styleUrls: ['./contacts-view.component.css']
})
export class ContactsViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
